import threading
import random
import time


class Customer(threading.Thread):
    def __init__(self, customer_id, num_items, dressing_rooms):
        threading.Thread.__init__(self)
        if not (1 <= num_items <= 6):
            raise ValueError("Customers can only take 1 to 6 items into the dressing room.")
        self.customer_id = customer_id
        self.num_items = num_items
        self.dressing_rooms = dressing_rooms

    def run(self):
        try:
            request_time = time.time()
            self.dressing_rooms.requestRoom(self.customer_id)
            wait_time = time.time() - request_time

            usage_time = 0
            for _ in range(self.num_items):
                try_on_time = random.randint(1, 3)
                time.sleep(try_on_time / 10)  # Simulate faster runtime
                usage_time += try_on_time

            self.dressing_rooms.releaseRoom(self.customer_id)

            with self.dressing_rooms.lock:
                print("Customer {} completed in {} minutes with a wait of {:.2f} seconds.".format(
                    self.customer_id, usage_time, wait_time))

        except Exception as e:
            with self.dressing_rooms.lock:
                print("Error for customer {}: {}".format(self.customer_id, str(e)))
