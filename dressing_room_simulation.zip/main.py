from dressing_room_simulation.dressing_rooms import DressingRooms
from dressing_room_simulation.customers import Customer
import random
import time


class Scenario:
    def __init__(self, num_rooms, num_customers):
        if not (1 <= num_rooms <= 50):
            raise ValueError("Number of rooms must be between 1 and 50.")
        if not (1 <= num_customers <= 100):
            raise ValueError("Number of customers must be between 1 and 100.")
        self.num_rooms = num_rooms
        self.num_customers = num_customers

    def run_scenario(self):
        print("Running scenario with {} rooms and {} customers...".format(self.num_rooms, self.num_customers))
        dressing_rooms = DressingRooms(self.num_rooms)
        customers = []

        for i in range(self.num_customers):
            num_items = random.randint(1, 6)  # Random items (1 to 6)
            customer = Customer(i + 1, num_items, dressing_rooms)
            customers.append(customer)

        for customer in customers:
            customer.start()

        for customer in customers:
            customer.join()

        print("Scenario with {} customers completed.".format(self.num_customers))


def main():
    try:
        scenarios = [
            Scenario(num_rooms=3, num_customers=10),
            Scenario(num_rooms=5, num_customers=20),
            Scenario(num_rooms=5, num_customers=30),
        ]
        for i, scenario in enumerate(scenarios, start=1):
            print("\n--- Scenario {} ---".format(i))
            scenario.run_scenario()
    except ValueError as ve:
        print("Input Error: {}".format(ve))
    except Exception as e:
        print("Unexpected Error: {}".format(e))


if __name__ == "__main__":
    main()
